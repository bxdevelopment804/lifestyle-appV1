import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

import SingleSquare from '../shared/single-square';
import FiveStarRating from '../shared/fiveStarRating';
import './generalRecipeFormatting.css';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEnvelope, faPrint } from '@fortawesome/free-solid-svg-icons';
import {
	faFacebook,
	faFacebookSquare,
	faInstagram,
	faPinterest,
	faPinterestSquare,
} from '@fortawesome/free-brands-svg-icons';

const HealthyFrenchToast = () => {
	useEffect(() => {
		window.scrollTo(0, 0);
	}, []);

	const [gradeIndex, setGradeIndex] = useState(-1);

	const changeGradeIndex = (index) => {
		setGradeIndex(index);
	};

	return (
		<div id='pageContainer'>
			<div id='sectionTitle'>DINNER</div>
			<div id='title'>Decadent French Toast Stuffed With Strawberries</div>
			<div id='rating'>
				<FiveStarRating
					gradeIndex={gradeIndex}
					changeGradeIndex={changeGradeIndex}
				/>
			</div>
			<div id='authorBlock'>
				<div id='authorInfo'>
					<img
						id='authorPhoto'
						className='authorPhoto'
						src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRNiB7xhtV400YhyOPtn5mrCawZZpCjAbrbWOtFWwfDXLxqvtpBtyJzWyZlPRWbHLBujqU&usqp=CAU'
						alt='author'
						width='75px'
						height='50px'
					/>
					<img
						id='authorPhoto2'
						className='authorPhoto'
						src='https://static.appliancesconnection.com/www/871x1350/site-info/images/blog/matt-goulding.jpg'
						alt='author'
						width='75px'
						height='50px'
					/>
					<div id='authorName' className='authorName'>
						by <strong>David Zinczenko</strong> and{' '}
						<strong>Matt Goulding</strong>
					</div>
				</div>
				<a href='#recipeSection'>
					<button id='recipeButton'>Jump to Recipe</button>
				</a>
			</div>
			<div id='media'>
				<FontAwesomeIcon icon={faPinterest} className='titleIcon' />
				<FontAwesomeIcon icon={faFacebook} className='titleIcon' />
				<FontAwesomeIcon icon={faEnvelope} className='titleIcon' />
			</div>
			<div id='date'>Published: January 7, 2019</div>
			<p id='description'>
				A breakfast so yummy, you'll find it hard to believe it's healthy.
			</p>
			<img
				id='image1'
				src='https://www.eatthis.com/wp-content/uploads/sites/4/2018/12/healthy-french-toast-with-strawberries.jpg?quality=82&strip=1&resize=970%2C546'
				alt='healthy french toast'
			/>
			<p id='videoHeader'>OUR LATEST VIDEOS</p>

			<iframe
				id='video1'
				width='560'
				height='315'
				src='https://www.youtube.com/embed/a8JKu4Pqe4E'
				title='YouTube video player'
				frameborder='0'
				allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture'
				allowfullscreen
			></iframe>
			<div id='title2'>Breakfast for Dinner? You Bet!</div>
			<img
				id='image2'
				src='https://www.modernhoney.com/wp-content/uploads/2017/03/DSC_0900-copy2.jpg'
				alt='healthy french toast'
			/>
			<p className='foodDescription'>
				Odds are, if the word "stuffed" is in the menu description, the dish is
				likely pretty dangerous. That's because restaurants choose to use
				"stuffed" as an excuse to sandwich extra quantities of the cheapest,
				highest-calorie ingredients they have on hand—in other words: fat,
				sugar, salt—into a meal that is already high in fat, sugar, and salt as
				it is. Case in point: stuffed French toast.
			</p>
			<div id='title3'>Decadent and Nutritious</div>
			<img
				id='image3'
				src='https://media.eggs.ca/assets/RecipeThumbs/_resampled/FillWyIxMjgwIiwiNzIwIl0/Stuffed-French-Toast.jpg'
				alt='healthy french toast'
			/>
			<p className='foodDescription'>
				At most places, the kitchen's stuffing technique takes a few pieces of
				thick bread and some fruit, and turns them into a dish with more than
				half your day's caloric allotment. But what if you stuffed your French
				Toast with some better for you, well…stuff? Done correctly, stuffing can
				actually be a nutritional boon: In this recipe, it adds a dose of
				low-cal protein, fiber, and all the energy-boosting vitamins from fresh
				strawberries and honey. Plus, it's simple enough to pull off, even on a
				weekday morning.
			</p>
			<div id='recipeSection'>
				<div id='rating2'>
					<FiveStarRating
						gradeIndex={gradeIndex}
						changeGradeIndex={changeGradeIndex}
					/>
				</div>
				<div id='headerContainer'>
					<div id='block1' className='headerItem'>
						Decadent French Toast Stuffed With Strawberries
					</div>
					<div id='block2' class='imageContainerWithButtons'>
						<img
							className='headerItem'
							src='https://feelgoodfoodie.net/wp-content/uploads/2017/01/Strawberry-Stuffed-French-Toast-11.jpg'
							width='100%'
						/>
						<div id='reviewRecipe'>
							<strong id='reviewRecipeText'>Review Recipe</strong>
						</div>
						<div id='pinRecipe'>
							<strong>Pin Recipe</strong>
						</div>
						<div id='printRecipe'>
							<FontAwesomeIcon icon={faPrint} className='printIcon' />
							&nbsp;&nbsp;
							<strong>Print Recipe</strong>
						</div>
					</div>
					<div id='block3' className='headerItem'>
						For a traditional breakfast or way of shaking up dinner, you can
						never go wrong with french toast.
					</div>
					<div id='block4' className='headerItem'>
						<div className='timeHeaders'>
							<strong>Prep Time</strong>
						</div>
						<div className='timeHeaders'>
							<strong>Cook Time</strong>
						</div>
						<div className='timeHeaders'>
							<strong>Total Time</strong>
						</div>
						<div className='cookTimes'>10 mins</div>
						<div className='cookTimes'>8 mins</div>
						<div className='cookTimes'>18 mins</div>
					</div>
					<div id='block5' className='headerItem'>
						<div className='subBlock-1'>
							<strong>Serves</strong>
						</div>
						<div className='subBlock-2'>4 people</div>
					</div>
					<div id='block6' className='headerItem'>
						<div className='subBlock-1'>
							<strong>Serving Size</strong>
						</div>
						<div className='subBlock-2'>1</div>
					</div>
					<div id='block7' className='headerItem'>
						<div className='subBlock-1'>
							<strong>Course</strong>
						</div>
						<div className='subBlock-2'>Dinner, Breakfast</div>
					</div>
					<div id='block8' className='headerItem'>
						<div className='subBlock-1'>
							<strong>Cuisine</strong>
						</div>
						<div className='subBlock-2'>French</div>
					</div>
					<div id='block9' className='headerItem'>
						<div className='subBlock-1'>
							<strong>Author</strong>
						</div>
						<div className='subBlock-2'>
							<strong id='redAuthor'>David Zinczenko and Matt Goulding</strong>
						</div>
					</div>
				</div>
				<div id='instructionContainer'>
					<div id='block16' className='instructionItem'>
						Ingredients
					</div>
					<div id='block17' className='instructionItem'>
						<ul>
							<li className='ingredient'>
								1 cup low-fat ricotta or cottage cheese
							</li>
							<li className='ingredient'>1⁄2 cup skim milk</li>
							<li className='ingredient'>2 cups strawberries, sliced</li>
							<li className='ingredient'>2 tbsp honey</li>
							<li className='ingredient'>2 tbsp sliced or chopped almonds</li>
							<li className='ingredient'>1 tbsp butter</li>
							<li className='ingredient'>2 eggs</li>
							<li className='ingredient'>1 cup milk</li>
							<li className='ingredient'>1⁄4 tsp cinnamon</li>
							<li className='ingredient'>1 tsp vanilla extract</li>
							<li className='ingredient'>8 slices whole wheat bread</li>
							<li className='ingredient'>powdered sugar (optional)</li>
						</ul>
					</div>
					<div id='block18' className='instructionItem'>
						Ad Space
					</div>
					<div id='block19' className='instructionItem'>
						Instructions
					</div>
					<div id='block20' className='instructionItem'>
						<ol id='instructionList' className='instructions'>
							<li className='instruction'>
								Place the ricotta, milk, strawberries, honey, and almonds in a
								mixing bowl and stir gently to combine. Set aside.
							</li>
							<li className='instruction'>
								Heat the butter in a large cast-iron skillet or nonstick pan
								over medium heat.
							</li>
							<li className='instruction'>
								Beat the eggs with the milk, cinnamon, and vanilla in a shallow
								dish.
							</li>
							<li className='instruction'>
								Working one slice at a time, place the bread in the egg mixture,
								turning it over once to thoroughly coat, then add it directly to
								the hot pan.
							</li>
							<li className='instruction'>Repeat until the pan is full.</li>
							<li className='instruction'>
								Cook each slice for 2 to 3 minutes per side, until a golden
								brown crust is formed.
							</li>
							<li className='instruction'>Remove from the pan.</li>
							<li className='instruction'>
								Divide the strawberry mixture among four slices of toast,
								spreading to evenly coat.
							</li>
							<li className='instruction'>
								Top them each with another slice to make a sandwich, then slice
								on the diagonal to create two equal triangles. Serve with a
								shake of powdered sugar or a drizzle of pure maple syrup, if you
								prefer.
							</li>
						</ol>
					</div>
					<div id='block21' className='instructionItem'>
						Nutrition Information
					</div>
					<div id='block22' className='instructionItem'>
						<div id='nutritionList'>
							<div className='nutritionItem'>Serving: 1serving |&nbsp;</div>
							<div className='nutritionItem'>Calories: 370kcal |&nbsp;</div>
							<div className='nutritionItem'>Carbohydrates: 22g |&nbsp;</div>
							<div className='nutritionItem'>Protein: 30g |&nbsp;</div>
							<div className='nutritionItem'>Fat: 14g |&nbsp;</div>
							<div className='nutritionItem'>Saturated Fat: 4g |&nbsp;</div>
							<div className='nutritionItem'>Trans Fat: 1g |&nbsp;</div>
							<div className='nutritionItem'>Cholesterol: 275mg |&nbsp;</div>
							<div className='nutritionItem'>Sodium: 1328mg |&nbsp;</div>
							<div className='nutritionItem'>Potassium: 640mg |&nbsp;</div>
							<div className='nutritionItem'>Fiber: 3g |&nbsp;</div>
							<div className='nutritionItem'>Sugar: 2g |&nbsp;</div>
							<div className='nutritionItem'>Vitamin A: 3031U |&nbsp;</div>
							<div className='nutritionItem'>Vitamin C: 50mg |&nbsp;</div>
							<div className='nutritionItem'>Iron: 4mg |&nbsp;</div>
							<div className='nutritionItem'>SmartPoints (FreeStyle): 10</div>
						</div>
					</div>
					<div id='block23' className='instructionItem'>
						<strong>Keywords</strong>&nbsp; Dinner, French, Breakfast
					</div>
					<div id='block24' className='instructionItem'>
						<div id='instagramPlaceholder'>
							<FontAwesomeIcon icon={faInstagram} className='instagramIcon' />
						</div>
						<div id='instagramText'>
							<div>
								<strong>Have you made this recipe?</strong>
							</div>
							<div>
								Tag @healthylifestyle on Instagram or hashtag it
								#healthlylifestyle
							</div>
						</div>
					</div>
					<div id='block25' className='instructionItem'>
						For more tasty recipes and lifestyle advice, make sure to like us on
						our <strong>Facebook</strong> page and follow us on{' '}
						<strong>Pinterest</strong>!
					</div>
					<div id='block26' className='instructionItem'>
						<div id='signup-bar'>
							<h1 id='signup-header-h1'>SAVE YOUR FAVORITE RECIPES</h1>
							<h3 id='signup-header-h3'>
								Create a FREE account for quick & easy access
							</h3>
							<div id='signup-bar-inputs'>
								<input type='text' />
								<button>START SAVING</button>
							</div>
						</div>
					</div>
					<div id='block27' className='instructionItem'>
						Share this recipe
					</div>
					<div id='block28' className='instructionItem'>
						<div id='facebookButton' className='socialMediaButtons'>
							<FontAwesomeIcon icon={faFacebookSquare} className='icon' />
							&nbsp;&nbsp;Facebook
						</div>
						<div id='pintrestButton' className='socialMediaButtons'>
							<FontAwesomeIcon icon={faPinterestSquare} className='icon' />
							&nbsp;&nbsp;Pin
						</div>
						<div id='emailButton' className='socialMediaButtons'>
							<FontAwesomeIcon icon={faEnvelope} className='icon' />
							&nbsp;&nbsp;Email
						</div>
					</div>
				</div>
				<div id='footerAuthContainer'>
					<div id='block29'>
						<img
							className='authorPhoto'
							src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRNiB7xhtV400YhyOPtn5mrCawZZpCjAbrbWOtFWwfDXLxqvtpBtyJzWyZlPRWbHLBujqU&usqp=CAU'
							alt='author'
							width='125px'
							height='100px'
						/>
						<img
							className='authorPhoto'
							src='https://static.appliancesconnection.com/www/871x1350/site-info/images/blog/matt-goulding.jpg'
							alt='author'
							width='125px'
							height='100px'
						/>
					</div>
					<div id='block30' className='footerAuthInfo'>
						David Zinczenko and Matt Goulding
					</div>
					<div id='block31' className='footerAuthInfo'>
						David Zinczenko is an American publisher, author, and businessman.
						Previously, he was the EVP and General Manager of Men's Health,
						Women's Health, Prevention and Rodale Books; Editorial Director of
						Men's Fitness; and the Nutrition and Wellness Editor at ABC News.
						<br /> Matt Goulding is an American food journalist, book author,
						and producer based in Barcelona, Spain. He was food editor at Men's
						Health magazine, where he wrote the column Eat This, Not That, which
						became a book series. In 2012, he co-founded Roads & Kingdoms with
						longtime foreign correspondent Nathan Thornburgh.
					</div>
					<div id='block32' className='footerAuthInfo'>
						More by David and Matt
					</div>
					<div id='block33' className='footerAuthInfo'>
						<div id='recipeKeywordList'>
							<div className='recipeKeyword'>Breakfast</div>
							<div className='recipeKeyword'>Dinner</div>
							<div className='recipeKeyword'>Sweet</div>
							<div className='recipeKeyword'>Fruit</div>
							<div className='recipeKeyword'>Chewy</div>
						</div>
					</div>
				</div>
				<div id='block34'>Related Recipes</div>
				<div id='footerLinkContainer'>
					<div id='block35' className='footerLinks'>
						<Link to='/healthyFrenchToast'>
							<SingleSquare
								url='https://www.eatthis.com/wp-content/uploads/sites/4/2018/12/healthy-french-toast-with-strawberries.jpg?quality=82&strip=1&resize=640%2C360'
								section='Dinner'
								title='Healthy French Toast With Strawberries'
								description='When you want something a little sweet for supper, look no further than this French toast recipe.'
								author='David Zinczenko and Matt Goulding'
							/>
						</Link>
					</div>
					<div id='block36' className='footerLinks'>
						<Link to='/asianChickenMeatballs'>
							<SingleSquare
								url='https://www.eatthis.com/wp-content/uploads/sites/4/2018/12/paleo-asian-chicken-meatballs.jpg?quality=82&strip=1&resize=640%2C360'
								section='Lunch'
								title='Asian Chicken Meatballs'
								description='Get your tastebuds ready for some bold flavors we bring for a twist on a classic dish.'
								author='David Zinczenko and Matt Goulding'
							/>
						</Link>
					</div>
					<div id='block37' className='footerLinks'>
						<Link to='/chickenZoodleSoup'>
							<SingleSquare
								url='https://www.eatthis.com/wp-content/uploads/sites/4/2019/12/Whole30-IP-Chicken-Zoodle-Soup.jpg?quality=82&strip=1&resize=640%2C360'
								section='Dinner'
								title='Instant Pot Chicken Zoodle Soup'
								description='Use zucchini noodles instead of regular ones to make a gluten-free chicken noodle soup.'
								author='Posie Brien'
							/>
						</Link>
					</div>
					<div id='block38' className='footerLinks'>
						<Link to='/italianTunaMelt'>
							<SingleSquare
								url='https://www.eatthis.com/wp-content/uploads/sites/4/2018/12/healthy-italian-tuna-melt.jpg?quality=82&strip=1&resize=970%2C546'
								section='Lunch'
								title='Italian Tuna Melt'
								description='A new and improved version of the classic sandwich that is ready to eat in minutes.'
								author='David Zinczenko and Matt Goulding'
							/>
						</Link>
					</div>
					<div id='block39' className='footerLinks'>
						<Link to='/chickenSaladSandwich'>
							<SingleSquare
								url='https://www.eatthis.com/wp-content/uploads/sites/4/2019/01/chicken-salad-sandwich-curry-raisins.jpg?quality=82&strip=1&resize=640%2C360'
								section='Lunch'
								title='Chicken Salad Sandwich with Curry and Raisins'
								description='Who said a chicken salad needs to be drowning in mayo to be tasty?'
								author='David Zinczenko and Matt Goulding'
							/>
						</Link>
					</div>
					<div id='block40' className='footerLinks'>
						<Link to='/healthyUltimateBurger'>
							<SingleSquare
								url='https://www.eatthis.com/wp-content/uploads/sites/4/2019/01/the-healthy-ultimate-burger.jpg?quality=82&strip=1&resize=970%2C546'
								section='Dinner'
								title='The Healthy Ultimate Burger'
								description='Prepare for a true, first-class burger experience.'
								author='David Zinczenko and Matt Goulding'
							/>
						</Link>
					</div>
					<div id='leaveReply' className='replyItem'>
						Leave A Reply
					</div>
					<div id='emailMessage' className='replyItem'>
						Your email address will not be published. Required fields are marked
						*
					</div>
					<div id='rating' className='replyItem'>
						<div id='rating3'>Recipe Rating</div>
						<div>
							<FiveStarRating
								gradeIndex={gradeIndex}
								changeGradeIndex={changeGradeIndex}
							/>
						</div>
					</div>
					<div id='commentText' className='replyItem'>
						Comment*
						<div id='commentBox' className='replyItem'></div>
					</div>
					<div id='nameText' className='replyItem'>
						Name*
						<div id='nameField' className='replyItem'></div>
					</div>
					<div id='emailText' className='replyItem'>
						Email*
						<div id='emailField' className='replyItem'></div>
					</div>
					<div id='postButton' className='replyItem'>
						Post Comment
					</div>
				</div>
			</div>
		</div>
	);
};

export default HealthyFrenchToast;
