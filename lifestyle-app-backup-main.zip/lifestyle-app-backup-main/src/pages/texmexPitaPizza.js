import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

import SingleSquare from '../shared/single-square';
import FiveStarRating from '../shared/fiveStarRating';
import './generalRecipeFormatting.css';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEnvelope, faPrint, faStar } from '@fortawesome/free-solid-svg-icons';
import {
	faFacebook,
	faFacebookSquare,
	faInstagram,
	faPinterest,
	faPinterestSquare,
} from '@fortawesome/free-brands-svg-icons';

const TexmexPitaPizza = () => {
	useEffect(() => {
		window.scrollTo(0, 0);
	}, []);

	const [gradeIndex, setGradeIndex] = useState(-1);

	const changeGradeIndex = (index) => {
		setGradeIndex(index);
	};

	return (
		<div id='pageContainer'>
			<div id='sectionTitle'>Plant-Based Recipes</div>
			<div id='title'>Tex-Mex Pita Pizzas</div>
			<div id='rating'>
				<FiveStarRating
					gradeIndex={gradeIndex}
					changeGradeIndex={changeGradeIndex}
				/>
			</div>
			<div id='authorBlock'>
				<div id='authorInfo'>
					<img
						id='authorPhoto'
						className='authorPhoto'
						src='https://www.forksoverknives.com/wp-content/uploads/fly-images/28913/Darshana-Thacker-732x506-1-494x341-c.jpg'
						alt='author'
						width='80px'
						height='50px'
					/>

					<div id='authorName' className='authorName'>
						by <strong>Darshana Thacker</strong>
					</div>
				</div>
				<a href='#recipeSection'>
					<button id='recipeButton'>Jump to Recipe</button>
				</a>
			</div>
			<div id='media'>
				<FontAwesomeIcon icon={faPinterest} className='titleIcon' />
				<FontAwesomeIcon icon={faFacebook} className='titleIcon' />
				<FontAwesomeIcon icon={faEnvelope} className='titleIcon' />
			</div>
			<div id='date'>Published: August 15, 2018</div>
			<p id='description'>Fresh flavours abound in this zingy pizza</p>
			<img
				id='image1'
				src='https://www.forksoverknives.com/wp-content/uploads/fly-images/66822/Tex-Mex-Pita-Pizzas_WP-688x387-c.jpg'
				alt='texmex pita pizza'
			/>
			<p id='videoHeader'>OUR LATEST VIDEOS</p>

			{/*REMINDER - Remember to insert id='video1' below whenever pasting embeds from Youtube. */}
			{/* id='video1' */}
			<iframe
				id='video1'
				width='560'
				height='315'
				src='https://www.youtube.com/embed/0Pbb7NHtVog'
				title='YouTube video player'
				frameborder='0'
				allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture'
				allowfullscreen
			></iframe>
			<div id='title2'>
				These will satisfy your taste buds and satiate your tum.
			</div>
			<img
				id='image2'
				src='https://www.readyseteat.com/sites/g/files/qyyrlu501/files/uploadedImages/img_5230_2164.jpg'
				alt='texmex pita pizza'
			/>

			<p className='foodDescription'>
				When you have fresh pita bread on hand—or any other flatbread, for that
				matter—homemade pizza is just minutes away.
			</p>
			<div id='title3'>
				These “pizzas” are what you get when you combine a few kitchen staples
				into something completely new.
			</div>
			<img
				id='image3'
				src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQWYmKhWHC11TUyKDqjiki_Yu1JtNTuUG4d6Q&usqp=CAU'
				alt='texmex pita pizza'
			/>

			<p className='foodDescription'>
				Topped with a tasty corn and black bean combo, these Tex-Mex pita pizzas
				are assembled after the pita crusts have been crisped in the oven so
				they won’t get soggy.
			</p>
			<p className='foodDescription'>
				We’ve kept the topping mild so it will appeal to adults and kids alike,
				but you can always adjust the heat level with the salsa you choose. To
				serve, cut each pizza into wedges or place whole on individual plates to
				be eaten with forks and knives.
			</p>

			<div id='recipeSection'>
				<div id='rating2'>
					<FiveStarRating
						gradeIndex={gradeIndex}
						changeGradeIndex={changeGradeIndex}
					/>
				</div>
				<div id='headerContainer'>
					<div id='block1' className='headerItem'>
						Tex-Mex Pita Pizzas
					</div>
					<div id='block2' class='imageContainerWithButtons'>
						<img
							className='headerItem'
							src='https://www.forksoverknives.com/wp-content/uploads/fly-images/66822/Tex-Mex-Pita-Pizzas_WP-688x387-c.jpg'
							width='100%'
						/>
						<div id='reviewRecipe'>
							<strong id='reviewRecipeText'>Review Recipe</strong>
						</div>
						<div id='pinRecipe'>
							<strong>Pin Recipe</strong>
						</div>
						<div id='printRecipe'>
							<FontAwesomeIcon icon={faPrint} className='printIcon' />
							&nbsp;&nbsp;
							<strong>Print Recipe</strong>
						</div>
					</div>
					<div id='block3' className='headerItem'>
						Try swapping the corn and beans with baby rocket and spinach leaves.
					</div>
					<div id='block4' className='headerItem'>
						<div className='timeHeaders'>
							<strong>Prep Time</strong>
						</div>
						<div className='timeHeaders'>
							<strong>Cook Time</strong>
						</div>
						<div className='timeHeaders'>
							<strong>Total Time</strong>
						</div>
						<div className='cookTimes'>15 mins</div>
						<div className='cookTimes'>15 mins</div>
						<div className='cookTimes'>30 mins</div>
					</div>
					<div id='block5' className='headerItem'>
						<div className='subBlock-1'>
							<strong>Serves</strong>
						</div>
						<div className='subBlock-2'>6 people</div>
					</div>
					<div id='block6' className='headerItem'>
						<div className='subBlock-1'>
							<strong>Serving Size</strong>
						</div>
						<div className='subBlock-2'>1</div>
					</div>
					<div id='block7' className='headerItem'>
						<div className='subBlock-1'>
							<strong>Course</strong>
						</div>
						<div className='subBlock-2'>Dinner</div>
					</div>
					<div id='block8' className='headerItem'>
						<div className='subBlock-1'>
							<strong>Cuisine</strong>
						</div>
						<div className='subBlock-2'>Tex-Mex</div>
					</div>
					<div id='block9' className='headerItem'>
						<div className='subBlock-1'>
							<strong>Author</strong>
						</div>
						<div className='subBlock-2'>
							<strong id='redAuthor'>Darshana Thacker</strong>
						</div>
					</div>
				</div>
				<div id='instructionContainer'>
					<div id='block16' className='instructionItem'>
						Ingredients
					</div>
					<div id='block17' className='instructionItem'>
						<ul>
							<li className='ingredient'>1 cup chopped onion</li>
							<li className='ingredient'>
								1 cup chopped bell pepper, any color
							</li>
							<li className='ingredient'>2 cloves garlic, minced</li>
							<li className='ingredient'>½ teaspoon ground cumin</li>
							<li className='ingredient'>
								1 15-ounce can black beans, rinsed and drained
							</li>
							<li className='ingredient'>1 cup fresh or frozen corn kernels</li>
							<li className='ingredient'>
								6 6- to 7-inch whole wheat pita rounds
							</li>
							<li className='ingredient'>1 cup chopped avocado</li>
							<li className='ingredient'>1 cup oil-free salsa</li>
							<li className='ingredient'>
								2 tablespoons snipped fresh cilantro
							</li>
						</ul>
					</div>
					<div id='block18' className='instructionItem'>
						Ad Space
					</div>
					<div id='block19' className='instructionItem'>
						Instructions
					</div>
					<div id='block20' className='instructionItem'>
						<ol id='instructionList' className='instructions'>
							<li className='instruction'>
								Preheat oven to 350°F. Line two baking sheets with parchment
								paper.
							</li>
							<li className='instruction'>
								In a large saucepan, bring ¼ cup of water to a boil. Add the
								onion, sweet pepper, garlic, and cumin; cook over medium-low
								heat for 10 minutes or until the onion is tender, stirring
								occasionally and adding additional water, 1 to 2 tablespoons at
								a time, as needed to prevent sticking. Stir in the beans and
								corn. Cook for 5 minutes more or until flavors are blended and
								beans and corn are heated through, stirring occasionally.
							</li>
							<li className='instruction'>
								Meanwhile, place the pita rounds on the prepared baking sheets.
								Bake for 10 to 15 minutes or until lightly toasted.
							</li>
							<li className='instruction'>
								While hot, add the zucchini noodles, then serve.Mash the
								avocado. Spread pita rounds with avocado and bean mixture. Top
								with salsa and sprinkle with cilantro.
							</li>
						</ol>
					</div>
					<div id='block21' className='instructionItem'>
						Nutrition Information
					</div>
					<div id='block22' className='instructionItem'>
						<div id='nutritionList'>
							<div className='nutritionItem'>Serving: 1serving |&nbsp;</div>
							<div className='nutritionItem'>Calories: 440kcal |&nbsp;</div>
							<div className='nutritionItem'>Carbohydrates: 22g |&nbsp;</div>
							<div className='nutritionItem'>Protein: 30g |&nbsp;</div>
							<div className='nutritionItem'>Fat: 15g |&nbsp;</div>
							<div className='nutritionItem'>Saturated Fat: 2g |&nbsp;</div>
							<div className='nutritionItem'>Trans Fat: 1g |&nbsp;</div>
							<div className='nutritionItem'>Cholesterol: 275mg |&nbsp;</div>
							<div className='nutritionItem'>Sodium: 510mg |&nbsp;</div>
							<div className='nutritionItem'>Potassium: 640mg |&nbsp;</div>
							<div className='nutritionItem'>Fiber: 3g |&nbsp;</div>
							<div className='nutritionItem'>Sugar: 2g |&nbsp;</div>
							<div className='nutritionItem'>Vitamin A: 3031U |&nbsp;</div>
							<div className='nutritionItem'>Vitamin C: 50mg |&nbsp;</div>
							<div className='nutritionItem'>Iron: 4mg |&nbsp;</div>
							<div className='nutritionItem'>SmartPoints (FreeStyle): 10</div>
						</div>
					</div>
					<div id='block23' className='instructionItem'>
						<strong>Keywords</strong>&nbsp; Dinner, Tex-Mex, Fusion
					</div>
					<div id='block24' className='instructionItem'>
						<div id='instagramPlaceholder'>
							<FontAwesomeIcon icon={faInstagram} className='instagramIcon' />
						</div>
						<div id='instagramText'>
							<div>
								<strong>Have you made this recipe?</strong>
							</div>
							<div>
								Tag @healthylifestyle on Instagram or hashtag it
								#healthlylifestyle
							</div>
						</div>
					</div>
					<div id='block25' className='instructionItem'>
						For more tasty recipes and lifestyle advice, make sure to like us on
						our <strong>Facebook</strong> page and follow us on{' '}
						<strong>Pinterest</strong>!
					</div>
					<div id='block26' className='instructionItem'>
						<div id='signup-bar'>
							<h1 id='signup-header-h1'>SAVE YOUR FAVORITE RECIPES</h1>
							<h3 id='signup-header-h3'>
								Create a FREE account for quick & easy access
							</h3>
							<div id='signup-bar-inputs'>
								<input type='text' />
								<button>START SAVING</button>
							</div>
						</div>
					</div>
					<div id='block27' className='instructionItem'>
						Share this recipe
					</div>
					<div id='block28' className='instructionItem'>
						<div id='facebookButton' className='socialMediaButtons'>
							<FontAwesomeIcon icon={faFacebookSquare} className='icon' />
							&nbsp;&nbsp;Facebook
						</div>
						<div id='pintrestButton' className='socialMediaButtons'>
							<FontAwesomeIcon icon={faPinterestSquare} className='icon' />
							&nbsp;&nbsp;Pin
						</div>
						<div id='emailButton' className='socialMediaButtons'>
							<FontAwesomeIcon icon={faEnvelope} className='icon' />
							&nbsp;&nbsp;Email
						</div>
					</div>
				</div>
				<div id='footerAuthContainer'>
					<div id='block29'>
						<img
							className='authorPhoto'
							src='https://www.forksoverknives.com/wp-content/uploads/fly-images/28913/Darshana-Thacker-732x506-1-494x341-c.jpg'
							alt='author'
							width='130px'
							height='100px'
						/>
					</div>
					<div id='block30' className='footerAuthInfo'>
						Darshana Thacker
					</div>
					<div id='block31' className='footerAuthInfo'>
						Darshana Thacker is chef and culinary project manager for Forks Over
						Knives. A graduate of the Natural Gourmet Institute, she is the
						author of Forks Over Knives: Flavor! She created the recipes for
						Forks Over Knives Family and was a lead recipe contributor to the
						New York Times bestseller The Forks Over Knives Plan. Her recipes
						have been published in The Prevent and Reverse Heart Disease
						Cookbook, Forks Over Knives—The Cookbook, Forks Over Knives: The
						Plant-Based Way to Health, and LA Yoga magazine online. Visit
						DarshanasKitchen.com for more.
					</div>
					<div id='block32' className='footerAuthInfo'>
						More by Darshana
					</div>
					<div id='block33' className='footerAuthInfo'>
						<div id='recipeKeywordList'>
							<div className='recipeKeyword'>Lunch</div>
							<div className='recipeKeyword'>Dinner</div>
							<div className='recipeKeyword'>Tex-Mex</div>
							<div className='recipeKeyword'>Fusion</div>
							<div className='recipeKeyword'>Sandwich</div>
						</div>
					</div>
				</div>
				<div id='block34'>Related Recipes</div>
				<div id='footerLinkContainer'>
					<div id='block35' className='footerLinks'>
						<Link to='/texmexPitaPizza'>
							<SingleSquare
								url='https://www.forksoverknives.com/wp-content/uploads/fly-images/66822/Tex-Mex-Pita-Pizzas_WP-688x387-c.jpg'
								section='Plant-Based Recipes'
								title='Tex-Mex Pita Pizzas'
								description='These will satisfy your taste buds and satiate your tum.'
								author='Darshana Thacker'
							/>
						</Link>
					</div>
					<div id='block36' className='footerLinks'>
						<Link to='/wildRiceSoup'>
							<SingleSquare
								url='https://www.forksoverknives.com/wp-content/uploads/fly-images/80859/Creamy-Wild-Rice-Soup-for-website-688x387-c.jpg'
								section='Plant-Based Recipes'
								title='Creamy Wild Rice Soup'
								description='	It’s like a chicken noodle soup but better.'
								author='Carla Christian'
							/>
						</Link>
					</div>
					<div id='block37' className='footerLinks'>
						<Link to='/veganBakedPotato'>
							<SingleSquare
								url='https://www.forksoverknives.com/wp-content/uploads/fly-images/42933/Nacho-and-Baked-Potato1561-WPedit-688x387-c.jpg'
								section='Plant-Based Recipes'
								title='"Nacho" Vegan Baked Potato'
								description='This recipe makes a great go-to meal when things are busy.'
								author='Andrea Duclos'
							/>
						</Link>
					</div>
					<div id='block38' className='footerLinks'>
						<Link to='/veganMacaroniCheese'>
							<SingleSquare
								url='https://www.forksoverknives.com/wp-content/uploads/fly-images/67930/Super-Stove-Top-Mac-and-Cheese-103068713-WP-688x387-c.jpg'
								section='Plant-Based Recipes'
								title='Stove-Top Vegan Macaroni and Cheese'
								description='This classic vegan mac and cheese is ultra cheesy, saucy and creamy.'
								author='Molly Patrick'
							/>
						</Link>
					</div>
					<div id='block39' className='footerLinks'>
						<Link to='/penneTomatoMushroom'>
							<SingleSquare
								url='https://www.forksoverknives.com/wp-content/uploads/fly-images/41259/Penne-with-Tomato-Mushroom-Cream-Sauce-wp-edit-688x387-c.jpg'
								section='Plant-Based Recipes'
								title='Penne With Tomato-Mushroom Sauce'
								description='Put an authentic Italian pasta dish on your dinner table in just 20 minutes.'
								author='Del Sroufe'
							/>
						</Link>
					</div>
					<div id='block40' className='footerLinks'>
						<Link to='/burritosRiceBeans'>
							<SingleSquare
								url='https://www.forksoverknives.com/wp-content/uploads/fly-images/22661/burrito-fok-300kb-688x387-c.jpg'
								section='Plant-Based Recipes'
								title='Burritos With Spanish Rice And Black Beans'
								description='Quick and easy, vegan bean and rice burritos are a perfect vegetarian dinner idea.'
								author='Susan Voisin'
							/>
						</Link>
					</div>
					<div id='leaveReply' className='replyItem'>
						Leave A Reply
					</div>
					<div id='emailMessage' className='replyItem'>
						Your email address will not be published. Required fields are marked
						*
					</div>
					<div id='rating' className='replyItem'>
						<div id='rating3'>Recipe Rating</div>
						<div>
							<FiveStarRating
								gradeIndex={gradeIndex}
								changeGradeIndex={changeGradeIndex}
							/>
						</div>
					</div>
					<div id='commentText' className='replyItem'>
						Comment*
						<div id='commentBox' className='replyItem'></div>
					</div>
					<div id='nameText' className='replyItem'>
						Name*
						<div id='nameField' className='replyItem'></div>
					</div>
					<div id='emailText' className='replyItem'>
						Email*
						<div id='emailField' className='replyItem'></div>
					</div>
					<div id='postButton' className='replyItem'>
						Post Comment
					</div>
				</div>
			</div>
		</div>
	);
};

export default TexmexPitaPizza;
